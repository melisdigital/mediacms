video-h264-001.mp4: simple audio+video file
video-h264-002.mp4: same as video-h264-001.mp4 but fragmented
